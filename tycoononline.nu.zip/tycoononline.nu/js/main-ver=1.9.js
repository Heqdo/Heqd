var sparadBgcolor, runTimer;

function dopopup()
{
	window.open('popUpIndex.php?typ=4','sponsor','height=390,width=360,resizable,scrollbars=yes');
}

function menyover(meny)
{
	document.getElementById(meny).style.visibility = "visible";
}

function menyout(meny, obj)
{
	//if (obj.id == 'meny1' || meny == 'nyheter')
	//{
		document.getElementById(meny).style.visibility = "hidden";
	//}
}

function mark(obj,color14)
{
	sparadBgcolor = obj.style.backgroundColor;

	obj.style.backgroundColor=color14;
}

function unmark(obj)
{
	obj.style.backgroundColor=sparadBgcolor;
}

function setFocusLogin(input)
{
	if (input == 1)
	{
		document.formLogin.password.focus();
	}
	else
	{
		document.formLogin.userName.focus();
	}
}

function setPaySystem(sys){
	if (sys=="walliecard")
	{
		document.getElementById("walliecard").style.display="block";
		document.getElementById("paypal").style.display="none";
		document.getElementById("walliecard_st4").style.display="block";
		document.getElementById("paypal_st4").style.display="none";
		document.getElementById("submit").src="https://betaal-met.wallie-card.nl/themes/default/logo.jpg";
	} else {
		document.getElementById("walliecard").style.display="none";
		document.getElementById("paypal").style.display="block";
		document.getElementById("walliecard_st4").style.display="none";
		document.getElementById("paypal_st4").style.display="block";
		document.getElementById("submit").src="https://www.paypal.com/en_US/i/btn/x-click-but02.gif";
	}	
}

function emptyValidator(obj,message)
{
	if (obj.value == "") 
	{
		alert(message);
		return false;
	}
}

function checkAll(name)
{
	obj = document.getElementsByName(name+'[]');
	for (i=0;i<obj.length;i++)
    	obj[i].checked=!obj[i].checked;
}

function trigger(name)
{
	var obj = document.getElementById(name);
	
	if (obj.style.display=='none')
		obj.style.display = 'block';
	else
		obj.style.display = 'none';
}

function processAjax(url) {
    

    if (window.XMLHttpRequest) { // Non-IE browsers
      req = new XMLHttpRequest();
      req.onreadystatechange = targetDiv;
      try {
        req.open("GET", url, true);
      } catch (e) {
        alert(e);
      }
      req.send(null);
    } else if (window.ActiveXObject) { // IE
      req = new ActiveXObject("Microsoft.XMLHTTP");
      if (req) {
        req.onreadystatechange = targetDiv;
        req.open("GET", url, true);
        req.send();

      }
    }
}

function targetDiv()
{
	if (req.readyState == 4)
	{ // Complete
		if (req.status == 200)
		{ // OK response
			document.getElementById("leaderboard").innerHTML = req.responseText;
		} else {
			alert("Problem: " + req.statusText);
		}
	}
}

function displayAd() {
	processAjax('/noframes/leaderboard.php');
	t = setTimeout("displayAd()", 60000);
}	


function updateTimers() {
  for (counter = 1; counter <= numCounters; counter++) {
    ctr = document.getElementById('ctr' + counter);
    timeRemaining = ctr.title;
    sec = timeRemaining;
    min = 0;
    hr = 0;
    day = 0;
    timestamp = new Date().getTime();
    timestamp_1 = parseInt(timestamp);
    timeRemaining_1 = parseInt(timeRemaining);
    display_date = timestamp_1 + timeRemaining_1;
    //ctr.style.border = parseInt(display_date);
    ctr.setAttribute('datetag', parseInt(display_date));
    if (sec < 0) {
      ctr.innerHTML = "-";
    } else {
      if (sec > 59) {
    	min = Math.floor(sec/60);
	    sec = sec - min * 60;
      }
      if (min > 59) {
    	hr = Math.floor(min / 60);
	    min = min - hr * 60;
      }
      if (hr > 24) {
    	day = Math.floor(hr / 24);
	  }
	  if (sec < 10) {
     	sec = "0" + sec;
      }
      if (min < 10) {
    	min = "0" + min;
      }
      if (day > 1) {
        hr = hr - day * 24;
      	partDay = Math.floor(hr / 24 * 10);
    	ctr.innerHTML = day + "." + partDay + "&nbsp;days";
      }
      else
      {
	     ctr.innerHTML = hr + ":" + min + ":" + sec + "";
      }
    }
    ctr.title = ctr.title - 1;
  }
  if (autoupdate != 2) {
  	clearTimeout(runTimer);
    runTimer = window.setTimeout("updateTimers();", 999);
  }
}

function unhide(divID) {
    var item = document.getElementById(divID);
    if (item) {
        item.className=(item.className=='hidden')?'unhidden':'hidden';
    }
}

var hide=false;

function toggleRows(tableId, tagid){

	tbl = document.getElementById(tableId);
	tag = document.getElementById(tagid);
	var len = tbl.rows.length;
	var vStyle = (hide)? "none":"";

	for(i=4 ; i< len; i++){
		 tbl.rows[i].style.display = vStyle;
	 }

	if(hide == true) {
		tag.innerHTML = "more...";
		hide = false;
	} else {
		tag.innerHTML = "...less";
		hide = true;
	}
}

function getOffsetRect(elem) {
	var box = elem.getBoundingClientRect()
	var body = document.body
	var docElem = document.documentElement
	var scrollTop = window.pageYOffset || docElem.scrollTop || body.scrollTop
	var scrollLeft = window.pageXOffset || docElem.scrollLeft || body.scrollLeft
	var clientTop = docElem.clientTop || body.clientTop || 0
	var clientLeft = docElem.clientLeft || body.clientLeft || 0
	var top  = box.top +  scrollTop - clientTop
	var left = box.left + scrollLeft - clientLeft
	return { top: Math.round(top), left: Math.round(left) }
	}

function addHilight(tutorialId,direction){
	if(direction=="none"){
		document.getElementById(tutorialId).className += ' tutorial';
		}
	else
		{
		cood = getOffsetRect(document.getElementById(tutorialId));
		var elem = document.createElement('img');
		if(direction=="sw"){
			var x = cood.left + 60;
			var y = cood.top - 110;
			document.getElementById(tutorialId).className += ' tutorial';
			document.getElementById('tutorialTest').innerHTML += "<div style='position:absolute; left:" + x + "px; top:" + y + "px;'><img class='arrow' src='/bilder/tutorialSW.png'></div>";
			}
		else if(direction=="nw"){
			var x = cood.left + 60;
			var y = cood.top + 30;
			document.getElementById(tutorialId).className += ' tutorial';
			document.getElementById('tutorialTest').innerHTML += "<div style='position:absolute; left:" + x + "px; top:" + y + "px;'><img class='arrow' src='/bilder/tutorialNW.png'></div>";
			}
		else if(direction=="ne"){
			var x = cood.left - 160;
			var y = cood.top + 30;
			document.getElementById(tutorialId).className += ' tutorial';
			document.getElementById('tutorialTest').innerHTML += "<div style='position:absolute; left:" + x + "px; top:" + y + "px;'><img class='arrow' src='/bilder/tutorialNE.png'></div>";
			}
		else if(direction=="se"){
			var x = cood.left - 160;
			var y = cood.top - 110;
			document.getElementById(tutorialId).className += ' tutorial';
			document.getElementById('tutorialTest').innerHTML += "<div style='position:absolute; left:" + x + "px; top:" + y + "px;'><img class='arrow' src='/bilder/tutorialSE.png'></div>";
			}
		}
	}